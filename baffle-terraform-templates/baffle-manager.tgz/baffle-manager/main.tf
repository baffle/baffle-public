#BAFFLE
#VERSION:4

locals {
  ZONE1 = "${var.region}-1"
}

resource "ibm_resource_group" "resource_group" {
  name     = var.resource_group
}

resource "ibm_is_vpc" "vpc1" {
  name = var.vpc_name
  resource_group = ibm_resource_group.resource_group.id
}

resource "ibm_is_public_gateway" "pgw1" {
    name = "pgw1"
    vpc = ibm_is_vpc.vpc1.id
    zone = "us-south-1"
    timeouts {
        create = "90m"
    }
}

resource "ibm_is_subnet" "subnet1" {
  name                     = "${var.vpc_name}-subnet1"
  vpc                      = ibm_is_vpc.vpc1.id
  zone                     = local.ZONE1
  total_ipv4_address_count = 256
  public_gateway           = ibm_is_public_gateway.pgw1.id
}

resource "ibm_container_vpc_cluster" "cluster" {
  name              = "${var.cluster_name}"
  vpc_id            = ibm_is_vpc.vpc1.id
  flavor            = var.flavor
  worker_count      = var.worker_count
  resource_group_id = ibm_resource_group.resource_group.id

  zones {
    subnet_id = ibm_is_subnet.subnet1.id
    name      = local.ZONE1
  }
}

#resource "ibm_container_vpc_worker_pool" "cluster_pool" {
#  cluster           = ibm_container_vpc_cluster.cluster.id
#  worker_pool_name  = "${var.worker_pool_name}"
#  flavor            = var.flavor
#  vpc_id            = ibm_is_vpc.vpc1.id
#  worker_count      = var.worker_count
#  resource_group_id = ibm_resource_group.resource_group.id
#  zones {
#    name      = local.ZONE1
#    subnet_id = ibm_is_subnet.subnet1.id
#  }
#}

data "ibm_container_cluster_config" "cluster_config" {
  cluster_name_id = ibm_container_vpc_cluster.cluster.id
}

provider "kubernetes" {
  host                   = data.ibm_container_cluster_config.cluster_config.host
  token                  = data.ibm_container_cluster_config.cluster_config.token
  cluster_ca_certificate = data.ibm_container_cluster_config.cluster_config.ca_certificate
}

resource "kubernetes_persistent_volume_claim" "baffle_mongo_pvc" {
  metadata {
    name = "baffle-mongo-pvc"
  }

  spec {
    access_modes = ["ReadWriteOnce"]

    resources {
      requests = {
        storage = "10Gi"
      }
    }

    storage_class_name = "ibmc-vpc-block-5iops-tier"
  }
}

resource "kubernetes_persistent_volume_claim" "baffle_manager_pvc" {
  metadata {
    name = "baffle-manager-pvc"
  }

  spec {
    access_modes = ["ReadWriteOnce"]

    resources {
      requests = {
        storage = "10Gi"
      }
    }

    storage_class_name = "ibmc-vpc-block-5iops-tier"
  }
}

resource "kubernetes_deployment" "baffle_mongo" {
  metadata {
    name = "baffle-mongo"

    labels = {
      app = "baffle-mongo"
    }
  }

  spec {
    replicas = 1

    selector {
      match_labels = {
        app = "baffle-mongo"
      }
    }

    template {
      metadata {
        labels = {
          app = "baffle-mongo"
        }
      }

      spec {
        volume {
          name = "baffle-mongodb-volume"

          persistent_volume_claim {
            claim_name = "baffle-mongo-pvc"
          }
        }

        container {
          name  = "mongodb"
          image = "${var.image_location}/baffle-mongodb:Release-Baffle.1.6.0.10"

          volume_mount {
            name       = "baffle-mongodb-volume"
            mount_path = "/data/db"
          }
        }
      }
    }

    strategy {
      type = "Recreate"
    }
  }
}

resource "kubernetes_service" "baffle_mongo" {
  metadata {
    name = "baffle-mongo"

    labels = {
      app = "baffle-mongo"
    }
  }

  spec {
    port {
      protocol    = "TCP"
      port        = 27017
      target_port = "27017"
    }

    selector = {
      app = "baffle-mongo"
    }

    type = "ClusterIP"
  }
}

resource "kubernetes_deployment" "baffle_manager" {
  metadata {
    name = "baffle-manager"

    labels = {
      app = "baffle-manager"
    }
  }

  spec {
    replicas = 1

    selector {
      match_labels = {
        app = "baffle-manager"
      }
    }

    template {
      metadata {
        labels = {
          app = "baffle-manager"
        }
      }

      spec {
        volume {
          name = "baffle-manager-volume"

          persistent_volume_claim {
            claim_name = "baffle-manager-pvc"
          }
        }

        container {
          name  = "baffle-manager"
          image = "${var.image_location}/baffle-manager:Release-Baffle.1.6.0.10"

          env {
            name  = "MONGO_IP"
            value = "baffle-mongo"
          }

          env {
            name  = "MONGO_PORT"
            value = "27017"
          }

          env {
            name  = "Deployment"
            value = "docker"
          }

          volume_mount {
            name       = "baffle-manager-volume"
            mount_path = "/opt/baffle/baffle-manager"
          }

          image_pull_policy = "Always"
        }
      }
    }

    strategy {
      type = "Recreate"
    }
  }
}

resource "kubernetes_service" "baffle_manager" {
  metadata {
    name = "baffle-manager"

    labels = {
      app = "baffle-manager"
    }
  }

  spec {
    port {
      protocol    = "TCP"
      port        = 8553
      target_port = "8553"
    }

    selector = {
      app = "baffle-manager"
    }

    type = "ClusterIP"
  }
}

resource "kubernetes_deployment" "baffle_web" {
  metadata {
    name = "baffle-web"

    labels = {
      app = "baffle-web"
    }
  }

  spec {
    replicas = 1

    selector {
      match_labels = {
        app = "baffle-web"
      }
    }

    template {
      metadata {
        labels = {
          app = "baffle-web"
        }
      }

      spec {
        container {
          name              = "baffle-web"
          image             = "${var.image_location}/baffle-web:Release-Baffle.1.6.0.10"
          image_pull_policy = "Always"
        }
      }
    }

    strategy {
      type = "Recreate"
    }
  }
}

resource "kubernetes_service" "baffle_web" {
  metadata {
    name = "baffle-web"

    labels = {
      app = "baffle-web"
    }
  }

  spec {
    port {
      protocol    = "TCP"
      port        = 8080
      target_port = "8080"
    }

    selector = {
      app = "baffle-web"
    }

    type = "ClusterIP"
  }
}

resource "kubernetes_deployment" "baffle_nginx" {
  metadata {
    name = "baffle-nginx"

    labels = {
      app = "baffle-nginx"
    }
  }

  spec {
    replicas = 1

    selector {
      match_labels = {
        app = "baffle-nginx"
      }
    }

    template {
      metadata {
        labels = {
          app = "baffle-nginx"
        }
      }

      spec {
        container {
          name    = "nginx"
          image   = "${var.image_location}/baffle-nginx:Release-Baffle.1.6.0.10"
          command = ["/bin/sh"]
          args    = ["-c", "envsubst '$$${BM_IP},$$${BM_URL},$$${WEB_URL}' < /etc/nginx/nginx.conf.template > /etc/nginx/nginx.conf && nginx -g 'daemon off;'"]

          env {
            name  = "BM_IP"
            value = "baffle-manager"
          }

          env {
            name  = "BM_URL"
            value = "http://baffle-manager:8553"
          }

          env {
            name  = "WEB_URL"
            value = "http://baffle-web:8080"
          }
        }
      }
    }

    strategy {
      type = "Recreate"
    }
  }
}


resource "kubernetes_service" "svc-nginx" {
  metadata {
    name = "baffle-nginx"

    labels = {
      app = "baffle-nginx"
    }
  }

  spec {
    port {
      protocol    = "TCP"
      port        = 443
      target_port = "443"
    }

    selector = {
      app = "baffle-nginx"
    }

    type = "LoadBalancer"
  }
}

locals {
  lb_name = kubernetes_service.svc-nginx
}

output "load_balancer_url" {
  value = kubernetes_service.svc-nginx.status.0.load_balancer.0.ingress.0.hostname
}
