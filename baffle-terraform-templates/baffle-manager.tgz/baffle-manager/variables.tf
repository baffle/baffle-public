variable "ibmcloud_api_key" {
  default = "NOTSET"
}

variable "iaas_classic_username" {
  default = "NOTSET"
}

variable "iaas_classic_api_key" {
  default = "NOTSET"
}

variable "resource_group" {
  default = "baffle"
}

variable "vpc_name" {
  default = "baffle-vpc"
}

variable "worker_pool_name" {
  default = "workerpool1"
}

variable "flavor" {
  default = "bx2.4x16"
}

variable "worker_count" {
  default = "1"
}

variable "cluster_name" {
  default = "baffle-cluster"
}

variable "region" {
  default = "us-south"
}

variable "image_location" {
  default = "us.icr.io/baffle"
}
