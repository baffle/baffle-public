variable "TF_VERSION" {
 description = "terraform version."
 default     = 0.13
}

variable "ibmcloud_api_key" {
  default = "NOTSET"
}

variable "iaas_classic_username" {
  default = "NOTSET"
}

variable "iaas_classic_api_key" {
  default = "NOTSET"
}

variable "baffle_version" {
  description = "Specify Baffle Release Version"
  default = "Release-Baffle.1.6.0.12"
}

variable "cluster_name" {
  default = "baffle-cluster"
}

variable "image_location" {
  default = "us.icr.io/baffle"
}

variable "BM_LB_URL" {
  default = "NOTSET"
}

variable "shield_sync_id" {
  default = "NOTSET"
}
