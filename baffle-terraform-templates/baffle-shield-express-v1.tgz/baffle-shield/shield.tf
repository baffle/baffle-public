#BAFFLE
#VERSION:4

data "ibm_container_cluster_config" "cluster_config" {
  cluster_name_id = var.cluster_name
}

provider "kubernetes" {
  host                   = data.ibm_container_cluster_config.cluster_config.host
  token                  = data.ibm_container_cluster_config.cluster_config.token
  cluster_ca_certificate = data.ibm_container_cluster_config.cluster_config.ca_certificate
}

resource "kubernetes_config_map" "shield-cm" {
  metadata {
    name = "baffle-shield-app1-config"
  }

  data = {
    BM_IP: var.BM_LB_URL
    BM_SHIELD_SYNC_ID: var.shield_sync_id
    BM_SHIELD_TAG = "baffle-shield-app1"
    BS_SSL = "true"
    BS_SSL_KEYSTORE_FILE = "/opt/sslconfig/baffleshield-keystore.jks"
    BS_SSL_KEYSTORE_PASSWORD = "keystore"
    BS_SSL_TLS_VERSION = "TLSv1.2"
    BS_SSL_TRUSTSTORE_FILE = "/opt/sslconfig/baffleshield-keystore.jks"
    BS_SSL_TRUSTSTORE_PASSWORD = "keystore"
    VERSION = var.baffle_version
  }
}

resource "kubernetes_deployment" "baffle_shield" {
  metadata {
    name = "baffle-shield-app1"

    labels = {
      app = "baffle-shield-app1"
    }
  }

  spec {
    replicas = 1

    selector {
      match_labels = {
        app = "baffle-shield-app1"
      }
    }

    template {
      metadata {
        labels = {
          app = "baffle-shield-app1"
        }
      }

      spec {
        container {
          name  = "baffle-shield-app1"
          image = "${var.image_location}/baffle-shield-postgresql:${var.baffle_version}"

          env_from {
            config_map_ref {
              name = "baffle-shield-app1-config"
            }
          }

          image_pull_policy = "Always"
        }
      }
    }

    strategy {
      type = "Recreate"
    }
  }
  
  depends_on = [kubernetes_config_map.shield-cm]
}


resource "kubernetes_service" "svc-shield" {
  metadata {
    name = "baffle-shield-app1"

    labels = {
      app = "baffle-shield-app1"
    }
  }

  spec {
    port {
      protocol    = "TCP"
      port        = 8444
      target_port = "8444"
    }

    selector = {
      app = "baffle-shield-app1"
    }

    type = "LoadBalancer"
  }
}

output "load_balancer_url" {
  value = kubernetes_service.svc-shield.status.0.load_balancer.0.ingress.0.hostname
}
