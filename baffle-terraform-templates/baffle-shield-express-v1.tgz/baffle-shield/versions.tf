terraform {
   required_providers {
      ibm = {
         source = "IBM-Cloud/ibm"
         version = "1.23.2"       
         }
      kubectl = {
         source  = "gavinbunney/kubectl"
	 version = ">= 1.7.0"
	 }
    }
}
