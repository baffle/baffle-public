variable "ibmcloud_api_key" {
  default = "NOTSET"
}

variable "iaas_classic_username" {
  default = "NOTSET"
}

variable "iaas_classic_api_key" {
  default = "NOTSET"
}

variable "cluster_name" {
  default = "baffle-cluster"
}

variable "image_location" {
  default = "us.icr.io/baffle"
}

variable "BM_LB_URL" {
  default = "NOTSET"
}

variable "shield_sync_id" {
  default = "NOTSET"
}
