variable "TF_VERSION" {
 description = "terraform version."
 default     = 0.13
}

variable "baffle_version" {
  description = "Specify Baffle Release Version"
  default = "Release-Baffle.1.6.0.12"
}

variable "ibmcloud_api_key" {
  description = "Specify IBM Cloud API Key"
  default = "NOTSET"
}

variable "iaas_classic_username" {
  description = "Specify the Username from the User details section"
  default = "NOTSET"
}

variable "iaas_classic_api_key" {
  description = "Specify Classic Infrastructure API Key"
  default = "NOTSET"
}

variable "cluster_name" {
  description = "Specify the k8s cluster to be created"
  default = "baffle-cluster"
}

variable "image_location" {
  description = "<container-registry/namespace>"
  default = "us.icr.io/baffle"
}
