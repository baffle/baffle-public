#BAFFLE
#VERSION:16


data "ibm_container_cluster_config" "cluster_config" {
  cluster_name_id = var.cluster_name
}

provider "kubernetes" {
  host                   = data.ibm_container_cluster_config.cluster_config.host
  token                  = data.ibm_container_cluster_config.cluster_config.token
  cluster_ca_certificate = data.ibm_container_cluster_config.cluster_config.ca_certificate
}

resource "kubernetes_persistent_volume_claim" "baffle_mongo_pvc" {
  metadata {
    name = "baffle-mongo-pvc"
  }

  spec {
    access_modes = ["ReadWriteOnce"]

    resources {
      requests = {
        storage = "10Gi"
      }
    }

    storage_class_name = "ibmc-vpc-block-5iops-tier"
  }

  timeouts {
    create = "60m"
  }
}

resource "kubernetes_persistent_volume_claim" "baffle_manager_pvc" {
  metadata {
    name = "baffle-manager-pvc"
  }

  spec {
    access_modes = ["ReadWriteOnce"]

    resources {
      requests = {
        storage = "10Gi"
      }
    }

    storage_class_name = "ibmc-vpc-block-5iops-tier"
  }
  timeouts {
    create = "60m"
  }
}

resource "kubernetes_deployment" "baffle_mongo" {
  metadata {
    name = "baffle-mongo"

    labels = {
      app = "baffle-mongo"
    }
  }

  spec {
    replicas = 1

    selector {
      match_labels = {
        app = "baffle-mongo"
      }
    }

    template {
      metadata {
        labels = {
          app = "baffle-mongo"
        }
      }

      spec {
        volume {
          name = "baffle-mongodb-volume"

          persistent_volume_claim {
            claim_name = "baffle-mongo-pvc"
          }
        }

        container {
          name  = "mongodb"
          image = "${var.image_location}/baffle-mongodb:${var.baffle_version}"

          volume_mount {
            name       = "baffle-mongodb-volume"
            mount_path = "/data/db"
          }
        }
      }
    }

    strategy {
      type = "Recreate"
    }
  }

  depends_on = [kubernetes_persistent_volume_claim.baffle_mongo_pvc]
}

resource "kubernetes_service" "baffle_mongo" {
  metadata {
    name = "baffle-mongo"

    labels = {
      app = "baffle-mongo"
    }
  }

  spec {
    port {
      protocol    = "TCP"
      port        = 27017
      target_port = "27017"
    }

    selector = {
      app = "baffle-mongo"
    }

    type = "ClusterIP"
  }
}

resource "kubernetes_deployment" "baffle_manager" {
  metadata {
    name = "baffle-manager"

    labels = {
      app = "baffle-manager"
    }
  }

  spec {
    replicas = 1

    selector {
      match_labels = {
        app = "baffle-manager"
      }
    }

    template {
      metadata {
        labels = {
          app = "baffle-manager"
        }
      }

      spec {
        volume {
          name = "baffle-manager-volume"

          persistent_volume_claim {
            claim_name = "baffle-manager-pvc"
          }
        }

        container {
          name  = "baffle-manager"
          image = "${var.image_location}/baffle-manager:${var.baffle_version}"

          env {
            name  = "MONGO_IP"
            value = "baffle-mongo"
          }

          env {
            name  = "MONGO_PORT"
            value = "27017"
          }

          env {
            name  = "Deployment"
            value = "docker"
          }

          volume_mount {
            name       = "baffle-manager-volume"
            mount_path = "/opt/baffle/baffle-manager"
          }

          image_pull_policy = "Always"
        }
      }
    }

    strategy {
      type = "Recreate"
    }
  }
  depends_on = [kubernetes_persistent_volume_claim.baffle_manager_pvc]
}

resource "kubernetes_service" "baffle_manager" {
  metadata {
    name = "baffle-manager"

    labels = {
      app = "baffle-manager"
    }
  }

  spec {
    port {
      protocol    = "TCP"
      port        = 8553
      target_port = "8553"
    }

    selector = {
      app = "baffle-manager"
    }

    type = "ClusterIP"
  }
}

resource "kubernetes_deployment" "baffle_web" {
  metadata {
    name = "baffle-web"

    labels = {
      app = "baffle-web"
    }
  }

  spec {
    replicas = 1

    selector {
      match_labels = {
        app = "baffle-web"
      }
    }

    template {
      metadata {
        labels = {
          app = "baffle-web"
        }
      }

      spec {
        container {
          name              = "baffle-web"
          image             = "${var.image_location}/baffle-web:${var.baffle_version}"
          image_pull_policy = "Always"
        }
      }
    }

    strategy {
      type = "Recreate"
    }
  }
}

resource "kubernetes_service" "baffle_web" {
  metadata {
    name = "baffle-web"

    labels = {
      app = "baffle-web"
    }
  }

  spec {
    port {
      protocol    = "TCP"
      port        = 8080
      target_port = "8080"
    }

    selector = {
      app = "baffle-web"
    }

    type = "ClusterIP"
  }
}

resource "kubernetes_deployment" "baffle_nginx" {
  metadata {
    name = "baffle-nginx"

    labels = {
      app = "baffle-nginx"
    }
  }

  spec {
    replicas = 1

    selector {
      match_labels = {
        app = "baffle-nginx"
      }
    }

    template {
      metadata {
        labels = {
          app = "baffle-nginx"
        }
      }

      spec {
        container {
          name    = "nginx"
          image   = "${var.image_location}/baffle-nginx:${var.baffle_version}"
          command = ["/bin/sh"]
          args    = ["-c", "envsubst '$$${BM_IP},$$${BM_URL},$$${WEB_URL}' < /etc/nginx/nginx.conf.template > /etc/nginx/nginx.conf && nginx -g 'daemon off;'"]

          env {
            name  = "BM_IP"
            value = "baffle-manager"
          }

          env {
            name  = "BM_URL"
            value = "http://baffle-manager:8553"
          }

          env {
            name  = "WEB_URL"
            value = "http://baffle-web:8080"
          }
        }
      }
    }

    strategy {
      type = "Recreate"
    }
  }
}


resource "kubernetes_service" "svc-nginx" {
  metadata {
    name = "baffle-nginx"

    labels = {
      app = "baffle-nginx"
    }
  }

  spec {
    port {
      protocol    = "TCP"
      port        = 443
      target_port = "443"
    }

    selector = {
      app = "baffle-nginx"
    }

    type = "LoadBalancer"
  }
}

locals {
  lb_name = kubernetes_service.svc-nginx
}

output "load_balancer_url" {
  value = kubernetes_service.svc-nginx.status.0.load_balancer.0.ingress.0.hostname
}
